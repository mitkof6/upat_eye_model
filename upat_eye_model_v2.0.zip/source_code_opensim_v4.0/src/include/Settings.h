#ifndef SETTINGS_H
#define SETTINGS_H

#include <string>

std::string MODEL_DIR = "D:/Desktop/upat_eye_model/source_code_opensim_v4.0/../model/";

#endif
