Description
---

Please check the buildinfo.txt file to check whether the fixation controller
plugin is built for your OpenSim version. If they agree, please copy these files
into the plugins folder located in the *OPENSIM_HOME* directory. If they don't
agree the source code of the plugin is provided.
